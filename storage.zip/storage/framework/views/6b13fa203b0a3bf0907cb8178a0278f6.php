<?php $__env->startSection('title', 'Sales Manager Dashboard - CRM'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Welcome Header -->
    <div id="welcome-section" class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 transition-all duration-1000 ease-in-out">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Welcome, <?php echo e(auth()->user()->name); ?>!</h1>
                <p class="text-gray-600 mt-1">Sales Manager Dashboard - CRM Focus</p>
                <p class="text-gray-500 text-sm mt-2">Manage your sales pipeline and customer relationships</p>
            </div>
            <div class="text-right">
                <div class="text-3xl font-bold text-gray-900"><?php echo e(date('d')); ?></div>
                <div class="text-gray-600 text-sm"><?php echo e(date('M Y')); ?></div>
            </div>
        </div>
    </div>

    <!-- CRM Quick Actions -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">CRM Quick Actions</h3>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            <a href="<?php echo e(route('leads.create')); ?>" class="group flex flex-col items-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl hover:from-blue-100 hover:to-blue-200 transition-all duration-300 shadow-sm hover:shadow-md border border-blue-200">
                <div class="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                    <i class="fas fa-user-plus text-white text-lg"></i>
                </div>
                <span class="text-sm font-semibold text-blue-800 text-center">Add Lead</span>
            </a>
            <a href="<?php echo e(route('quotations.create')); ?>" class="group flex flex-col items-center p-6 bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl hover:from-orange-100 hover:to-orange-200 transition-all duration-300 shadow-sm hover:shadow-md border border-orange-200">
                <div class="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                    <i class="fas fa-file-invoice text-white text-lg"></i>
                </div>
                <span class="text-sm font-semibold text-orange-800 text-center">Create Quotation</span>
            </a>
            <a href="#" class="group flex flex-col items-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl hover:from-purple-100 hover:to-purple-200 transition-all duration-300 shadow-sm hover:shadow-md border border-purple-200">
                <div class="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                    <i class="fas fa-users text-white text-lg"></i>
                </div>
                <span class="text-sm font-semibold text-purple-800 text-center">Add Customer</span>
            </a>
            <a href="<?php echo e(route('leads.index')); ?>" class="group flex flex-col items-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl hover:from-green-100 hover:to-green-200 transition-all duration-300 shadow-sm hover:shadow-md border border-green-200">
                <div class="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                    <i class="fas fa-list text-white text-lg"></i>
                </div>
                <span class="text-sm font-semibold text-green-800 text-center">View Leads</span>
            </a>
            <a href="<?php echo e(route('crm.dashboard')); ?>" class="group flex flex-col items-center p-6 bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-xl hover:from-indigo-100 hover:to-indigo-200 transition-all duration-300 shadow-sm hover:shadow-md border border-indigo-200">
                <div class="w-12 h-12 bg-indigo-500 rounded-full flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                    <i class="fas fa-chart-bar text-white text-lg"></i>
                </div>
                <span class="text-sm font-semibold text-indigo-800 text-center">CRM Analytics</span>
            </a>
        </div>
    </div>

    <!-- CRM Performance Row -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Total Leads Card -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-300">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                        <i class="fas fa-user-plus text-blue-600 text-xl"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-gray-600">Total Leads</p>
                        <p class="text-2xl font-semibold text-gray-900"><?php echo e(number_format($stats['total_leads'])); ?></p>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between">
                <span class="text-sm text-blue-600 font-medium"><?php echo e($stats['new_leads']); ?> New</span>
                <div class="flex items-center text-xs text-gray-500">
                    <i class="fas fa-chart-line mr-1"></i>
                    Lead Pipeline
                </div>
            </div>
        </div>

        <!-- Converted Leads Card -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-300">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                        <i class="fas fa-check-circle text-green-600 text-xl"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-gray-600">Converted Leads</p>
                        <p class="text-2xl font-semibold text-gray-900"><?php echo e(number_format($stats['converted_leads'])); ?></p>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between">
                <span class="text-sm text-green-600 font-medium"><?php echo e($stats['converted_leads'] > 0 ? round(($stats['converted_leads'] / $stats['total_leads']) * 100, 1) : 0); ?>% Rate</span>
                <div class="flex items-center text-xs text-gray-500">
                    <i class="fas fa-percentage mr-1"></i>
                    Conversion
                </div>
            </div>
        </div>

        <!-- Total Projects Card -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-300">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                        <i class="fas fa-project-diagram text-orange-600 text-xl"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-gray-600">Total Projects</p>
                        <p class="text-2xl font-semibold text-gray-900"><?php echo e(number_format($stats['total_projects'])); ?></p>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between">
                <span class="text-sm text-orange-600 font-medium"><?php echo e($stats['active_projects']); ?> Active</span>
                <div class="flex items-center text-xs text-gray-500">
                    <i class="fas fa-chart-bar mr-1"></i>
                    Project Status
                </div>
            </div>
        </div>

        <!-- Total Revenue Card -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-300">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-emerald-50 rounded-lg flex items-center justify-center">
                        <i class="fas fa-rupee-sign text-emerald-600 text-xl"></i>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium text-gray-600">Total Revenue</p>
                        <p class="text-2xl font-semibold text-gray-900">₹<?php echo e(number_format($stats['total_revenue'])); ?></p>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-between">
                <span class="text-sm text-emerald-600 font-medium">Paid Invoices</span>
                <div class="flex items-center text-xs text-gray-500">
                    <i class="fas fa-chart-line mr-1"></i>
                    Revenue
                </div>
            </div>
        </div>
    </div>

    <!-- CRM Activity Section -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Recent Leads -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900">Recent Leads</h3>
                <a href="<?php echo e(route('leads.index')); ?>" class="text-blue-600 hover:text-blue-800 text-sm font-medium">View All</a>
            </div>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $recentLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-blue-600 text-sm"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900"><?php echo e($lead->name); ?></p>
                            <p class="text-xs text-gray-500"><?php echo e($lead->company ?? 'No Company'); ?></p>
                        </div>
                    </div>
                    <span class="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                        <?php echo e(ucfirst($lead->status)); ?>

                    </span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500 text-sm text-center py-4">No recent leads</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Projects -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900">Recent Projects</h3>
                <a href="<?php echo e(route('projects.index')); ?>" class="text-blue-600 hover:text-blue-800 text-sm font-medium">View All</a>
            </div>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $recentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-project-diagram text-orange-600 text-sm"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900"><?php echo e($project->name); ?></p>
                            <p class="text-xs text-gray-500"><?php echo e($project->client->name ?? 'No Client'); ?></p>
                        </div>
                    </div>
                    <span class="px-2 py-1 text-xs font-medium bg-orange-100 text-orange-800 rounded-full">
                        <?php echo e(ucfirst($project->status)); ?>

                    </span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500 text-sm text-center py-4">No recent projects</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Quotations -->
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900">Recent Quotations</h3>
                <a href="<?php echo e(route('quotations.index')); ?>" class="text-blue-600 hover:text-blue-800 text-sm font-medium">View All</a>
            </div>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $recentQuotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-file-invoice text-purple-600 text-sm"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900"><?php echo e($quotation->title ?? 'Quotation #' . $quotation->id); ?></p>
                            <p class="text-xs text-gray-500">₹<?php echo e(number_format($quotation->total_amount ?? 0)); ?></p>
                        </div>
                    </div>
                    <span class="px-2 py-1 text-xs font-medium bg-purple-100 text-purple-800 rounded-full">
                        <?php echo e(ucfirst($quotation->status ?? 'Draft')); ?>

                    </span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500 text-sm text-center py-4">No recent quotations</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const welcomeSection = document.getElementById('welcome-section');
    
    if (welcomeSection) {
        // Hide welcome section after 4 seconds with fade out animation
        setTimeout(function() {
            welcomeSection.style.opacity = '0';
            welcomeSection.style.transform = 'translateY(-20px)';
            
            // Remove element from DOM after animation completes
            setTimeout(function() {
                welcomeSection.style.display = 'none';
            }, 1000); // Wait for transition to complete
        }, 4000); // 4 seconds delay
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/krish/Desktop/solar-erp/resources/views/dashboards/sales-manager.blade.php ENDPATH**/ ?>