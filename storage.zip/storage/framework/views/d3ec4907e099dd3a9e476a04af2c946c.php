<?php $__env->startSection('title', 'Leads Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h1 class="text-3xl font-bold text-gray-900">Leads Management</h1>
            <p class="mt-2 text-gray-600">Manage your sales leads and prospects</p>
        </div>
        <div class="mt-4 sm:mt-0 flex space-x-3">
            <button onclick="openImportModal()" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10"></path>
                </svg>
                Import via Excel
            </button>
            <a href="<?php echo e(route('leads.create')); ?>" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path>
                </svg>
                Add New Lead
            </a>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <div class="bg-white rounded-lg shadow p-4">
            <div class="flex items-center">
                <div class="p-2 bg-blue-100 rounded-lg">
                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-600">Total</p>
                    <p class="text-xl font-bold text-gray-900"><?php echo e(number_format($stats['total'])); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-4">
            <div class="flex items-center">
                <div class="p-2 bg-yellow-100 rounded-lg">
                    <svg class="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-600">New</p>
                    <p class="text-xl font-bold text-gray-900"><?php echo e(number_format($stats['new'])); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-4">
            <div class="flex items-center">
                <div class="p-2 bg-blue-100 rounded-lg">
                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-600">Contacted</p>
                    <p class="text-xl font-bold text-gray-900"><?php echo e(number_format($stats['contacted'])); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-4">
            <div class="flex items-center">
                <div class="p-2 bg-green-100 rounded-lg">
                    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-600">Qualified</p>
                    <p class="text-xl font-bold text-gray-900"><?php echo e(number_format($stats['qualified'])); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-4">
            <div class="flex items-center">
                <div class="p-2 bg-purple-100 rounded-lg">
                    <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm font-medium text-gray-600">Converted</p>
                    <p class="text-xl font-bold text-gray-900"><?php echo e(number_format($stats['converted'])); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Email Lookup -->
    <div class="bg-white shadow rounded-lg p-6 mb-6">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Check Lead Details via Email</h3>
        <form method="POST" action="<?php echo e(route('leads.lookup-by-email')); ?>" class="flex gap-4">
            <?php echo csrf_field(); ?>
            <div class="flex-1">
                <input type="email" name="email" required 
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                       placeholder="Enter email address to lookup lead...">
            </div>
            <button type="submit" class="px-4 py-2 bg-teal-600 text-white rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500">
                <svg class="w-5 h-5 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                </svg>
                Lookup
            </button>
        </form>
    </div>

    <!-- Filters -->
    <div class="bg-white shadow rounded-lg p-6">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" 
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                       placeholder="Search leads...">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-teal-500 focus:border-teal-500">
                    <option value="">All Status</option>
                    <option value="new" <?php echo e(request('status') == 'new' ? 'selected' : ''); ?>>New</option>
                    <option value="contacted" <?php echo e(request('status') == 'contacted' ? 'selected' : ''); ?>>Contacted</option>
                    <option value="qualified" <?php echo e(request('status') == 'qualified' ? 'selected' : ''); ?>>Qualified</option>
                    <option value="proposal" <?php echo e(request('status') == 'proposal' ? 'selected' : ''); ?>>Proposal</option>
                    <option value="negotiation" <?php echo e(request('status') == 'negotiation' ? 'selected' : ''); ?>>Negotiation</option>
                    <option value="converted" <?php echo e(request('status') == 'converted' ? 'selected' : ''); ?>>Converted</option>
                    <option value="lost" <?php echo e(request('status') == 'lost' ? 'selected' : ''); ?>>Lost</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Source</label>
                <select name="source" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-teal-500 focus:border-teal-500">
                    <option value="">All Sources</option>
                    <option value="website" <?php echo e(request('source') == 'website' ? 'selected' : ''); ?>>Website</option>
                    <option value="indiamart" <?php echo e(request('source') == 'indiamart' ? 'selected' : ''); ?>>IndiaMart</option>
                    <option value="justdial" <?php echo e(request('source') == 'justdial' ? 'selected' : ''); ?>>JustDial</option>
                    <option value="meta_ads" <?php echo e(request('source') == 'meta_ads' ? 'selected' : ''); ?>>Meta Ads</option>
                    <option value="referral" <?php echo e(request('source') == 'referral' ? 'selected' : ''); ?>>Referral</option>
                    <option value="cold_call" <?php echo e(request('source') == 'cold_call' ? 'selected' : ''); ?>>Cold Call</option>
                    <option value="other" <?php echo e(request('source') == 'other' ? 'selected' : ''); ?>>Other</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Assigned To</label>
                <select name="assigned_to" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-teal-500 focus:border-teal-500">
                    <option value="">All Users</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>" <?php echo e(request('assigned_to') == $user->id ? 'selected' : ''); ?>>
                            <?php echo e($user->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="flex items-end">
                <button type="submit" class="w-full px-4 py-2 bg-teal-600 text-white rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500">
                    Filter
                </button>
            </div>
        </form>
    </div>

    <!-- Leads Table -->
    <div class="bg-white shadow overflow-hidden sm:rounded-md">
        <div class="px-4 py-5 sm:p-6">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="w-32 px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lead</th>
                            <th class="w-24 px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                            <th class="w-20 px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Source</th>
                            <th class="w-20 px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="w-16 px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
                            <th class="w-20 px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                            <th class="w-24 px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-3 py-3 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-8 w-8">
                                        <div class="h-8 w-8 rounded-full bg-teal-500 flex items-center justify-center">
                                            <span class="text-xs font-medium text-white"><?php echo e(substr($lead->name, 0, 1)); ?></span>
                                        </div>
                                    </div>
                                    <div class="ml-2">
                                        <div class="text-xs font-medium text-gray-900 truncate" title="<?php echo e($lead->name); ?>"><?php echo e(Str::limit($lead->name, 15)); ?></div>
                                        <div class="text-xs text-gray-500 truncate" title="<?php echo e($lead->company ?? 'No Company'); ?>"><?php echo e(Str::limit($lead->company ?? 'No Company', 12)); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-3 py-3 whitespace-nowrap">
                                <div class="text-xs text-gray-900 truncate" title="<?php echo e($lead->phone); ?>"><?php echo e(Str::limit($lead->phone, 12)); ?></div>
                                <div class="text-xs text-gray-500 truncate" title="<?php echo e($lead->email ?? 'No Email'); ?>"><?php echo e(Str::limit($lead->email ?? 'No Email', 12)); ?></div>
                            </td>
                            <td class="px-3 py-3 whitespace-nowrap">
                                <span class="inline-flex items-center px-1 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $lead->source))); ?>

                                </span>
                            </td>
                            <td class="px-3 py-3 whitespace-nowrap">
                                <span class="inline-flex items-center px-1 py-0.5 rounded-full text-xs font-medium <?php echo e($lead->status_badge); ?>">
                                    <?php echo e(ucfirst($lead->status)); ?>

                                </span>
                            </td>
                            <td class="px-3 py-3 whitespace-nowrap">
                                <span class="inline-flex items-center px-1 py-0.5 rounded-full text-xs font-medium <?php echo e($lead->priority_badge); ?>">
                                    <?php echo e(ucfirst($lead->priority)); ?>

                                </span>
                            </td>
                            <td class="px-3 py-3 whitespace-nowrap text-xs text-gray-900">
                                <?php echo e($lead->estimated_value ? '₹' . number_format($lead->estimated_value) : 'N/A'); ?>

                            </td>
                            <td class="px-3 py-3 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-1">
                                    <a href="<?php echo e(route('leads.show', $lead)); ?>" class="text-teal-600 hover:text-teal-900 text-xs leading-none">View</a>
                                    <a href="<?php echo e(route('leads.edit', $lead)); ?>" class="text-indigo-600 hover:text-indigo-900 text-xs leading-none">Edit</a>
                                    <button type="button" onclick="openDeleteModal(<?php echo e($lead->id); ?>, '<?php echo e($lead->name); ?>')" class="text-red-600 hover:text-red-900 text-xs leading-none bg-transparent border-none p-0">Delete</button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-3 py-4 text-center text-gray-500">No leads found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="mt-6">
                <?php echo e($leads->links()); ?>

            </div>
        </div>
    </div>
</div>

<!-- Excel Import Modal -->
<div id="importModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Import Leads from Excel</h3>
            
            <!-- Demo File Download Section -->
            <div class="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                <div class="flex items-center justify-between">
                    <div>
                        <h4 class="text-sm font-medium text-green-900 mb-1">Need a sample file?</h4>
                        <p class="text-xs text-green-700">Download our demo CSV template</p>
                    </div>
                    <a href="<?php echo e(route('leads.download-template')); ?>" class="inline-flex items-center px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-md transition-colors duration-200">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                        Download Template
                    </a>
                </div>
            </div>
            
            <form method="POST" action="<?php echo e(route('leads.import')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                
                <div class="mb-4">
                    <label for="excel_file" class="block text-sm font-medium text-gray-700 mb-2">Select Excel File *</label>
                    <input type="file" id="excel_file" name="excel_file" accept=".xlsx,.xls,.csv" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500">
                    <p class="text-xs text-gray-500 mt-1">Supported formats: .xlsx, .xls, .csv</p>
                </div>
                
                <div class="mb-4">
                    <div class="bg-blue-50 p-3 rounded-lg">
                        <h4 class="text-sm font-medium text-blue-900 mb-2">Required Columns:</h4>
                        <ul class="text-xs text-blue-800 space-y-1">
                            <li>• Name (required)</li>
                            <li>• Phone (required)</li>
                            <li>• Email (optional)</li>
                            <li>• Company (optional)</li>
                            <li>• Source (required)</li>
                            <li>• Status (required)</li>
                            <li>• Priority (required)</li>
                        </ul>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="closeImportModal()" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg">
                        Cancel
                    </button>
                    <button type="submit" class="bg-teal-600 hover:bg-teal-700 text-white px-4 py-2 rounded-lg">
                        Import Leads
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openImportModal() {
    document.getElementById('importModal').classList.remove('hidden');
}

function closeImportModal() {
    document.getElementById('importModal').classList.add('hidden');
    // Reset form
    document.querySelector('#importModal form').reset();
}

// Close modal when clicking outside
document.getElementById('importModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeImportModal();
    }
});

function openDeleteModal(leadId, leadName) {
    document.getElementById('deleteLeadName').textContent = leadName;
    const form = document.getElementById('deleteForm');
    form.action = '<?php echo e(url("/leads")); ?>/' + leadId;
    // Clear the reason field
    document.getElementById('delete_reason').value = '';
    document.getElementById('deleteModal').classList.remove('hidden');
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.add('hidden');
    document.getElementById('deleteForm').reset();
}

// Close delete modal when clicking outside
document.getElementById('deleteModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeDeleteModal();
    }
});
</script>

<!-- Delete Lead Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Delete Lead</h3>
            <p class="text-sm text-gray-600 mb-4">Are you sure you want to delete lead: <strong id="deleteLeadName"></strong>?</p>
            <?php if(auth()->user()->hasRole('SUPER ADMIN')): ?>
            <p class="text-xs text-yellow-600 mb-4">The lead will be backed up for 40 days and can be restored from Lead Backups.</p>
            <?php else: ?>
            <p class="text-xs text-yellow-600 mb-4">This will require approval from Admin. The lead will be backed up for 40 days after approval.</p>
            <?php endif; ?>
            
            <form id="deleteForm" method="POST" action="">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                
                <div class="mb-4">
                    <label for="delete_reason" class="block text-sm font-medium text-gray-700 mb-2">Reason for Deletion <?php if(!auth()->user()->hasRole('SUPER ADMIN')): ?><span class="text-red-500">*</span><?php endif; ?></label>
                    <textarea id="delete_reason" name="reason" rows="3" <?php if(!auth()->user()->hasRole('SUPER ADMIN')): ?>required minlength="10"<?php endif; ?>
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                              placeholder="Enter reason for deletion<?php echo e(!auth()->user()->hasRole('SUPER ADMIN') ? ' (minimum 10 characters)' : ' (optional)'); ?>..."></textarea>
                    <p class="text-xs text-gray-500 mt-1">
                        <?php if(auth()->user()->hasRole('SUPER ADMIN')): ?>
                            Reason is optional for Super Admin.
                        <?php else: ?>
                            Please provide a detailed reason for deletion (minimum 10 characters).
                        <?php endif; ?>
                    </p>
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="closeDeleteModal()" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg">
                        Cancel
                    </button>
                    <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg">
                        <?php if(auth()->user()->hasRole('SUPER ADMIN')): ?>
                            Delete Lead
                        <?php else: ?>
                            Request Deletion
                        <?php endif; ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/krish/Desktop/solar-erp/resources/views/leads/index.blade.php ENDPATH**/ ?>